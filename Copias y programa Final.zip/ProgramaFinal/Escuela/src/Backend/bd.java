/* CODIGO REALIZADO EL DIA 25 DE NOVIEMBRE DEL 2023 CON NETBEANS 8.0*/
package Backend;
//Aqui va todo el codigo relacionado solo con la conexion a la bd

import java.sql.Connection;
import java.sql.DriverManager;


public class bd {
   //variable para la conexion
    Connection con;
    
    //Funcion para la conexion
    public bd(){
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/colegio", "root","");
        } catch (Exception e) {
            System.err.println("No se conecto a la base de datos. error"+ e);
        }
    
    }
    public Connection getConnection(){
        return con;
    }
    
}
