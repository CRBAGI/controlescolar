/* CODIGO REALIZADO EL DIA 25 DE NOVIEMBRE DEL 2023 CON NETBEANS 8.0*/
package Backend;
//Aqui va todo el codigo relacionado solo con la conexion a la BD

public class BD {
    
}
